import { NextResponse } from "next/server";
import { sql } from "@vercel/postgres";
import { ensureSchema } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request) {
  try {
    await ensureSchema();
    const { orders, lineItems } = await request.json();

    if (!Array.isArray(orders) || !Array.isArray(lineItems)) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
    }

    let inserted = 0;
    let skipped = 0;

    for (const o of orders) {
      // ON CONFLICT DO NOTHING = deduplication. Same order Id won't be inserted twice.
      const result = await sql`
        INSERT INTO orders (id, name, created_at, total, subtotal, financial_status, source, payment_method, currency)
        VALUES (${o.id}, ${o.name}, ${o.created_at}, ${o.total}, ${o.subtotal},
                ${o.financial_status}, ${o.source}, ${o.payment_method}, ${o.currency})
        ON CONFLICT (id) DO NOTHING
        RETURNING id;
      `;
      if (result.rowCount > 0) {
        inserted += 1;
        // Insert this order's line items
        const itemsForOrder = lineItems.filter((li) => li.order_id === o.id);
        for (const li of itemsForOrder) {
          await sql`
            INSERT INTO line_items (order_id, product_base, product_full, size, quantity, price, sku)
            VALUES (${li.order_id}, ${li.product_base}, ${li.product_full},
                    ${li.size}, ${li.quantity}, ${li.price}, ${li.sku});
          `;
        }
      } else {
        skipped += 1;
      }
    }

    return NextResponse.json({ inserted, skipped, total: orders.length });
  } catch (err) {
    console.error("Import error:", err);
    return NextResponse.json(
      { error: err.message || "Import failed" },
      { status: 500 }
    );
  }
}
