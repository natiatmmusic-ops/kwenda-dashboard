import Link from "next/link";
import StatCard from "@/components/StatCard";
import SectionLabel from "@/components/SectionLabel";
import SalesTrendChart from "@/components/charts/SalesTrendChart";
import ChannelDonut from "@/components/charts/ChannelDonut";
import { getDashboardStats } from "@/lib/computeStats";
import { Upload } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function SalesPage() {
  const stats = await getDashboardStats();

  if (!stats.hasData) {
    return (
      <div className="card p-10 text-center shadow-card">
        <Upload size={32} strokeWidth={1.5} className="mx-auto mb-4 text-ash" />
        <div className="font-display text-xl uppercase tracking-wide mb-2">
          No sales data yet
        </div>
        <p className="text-[13px] text-ash mb-6">Import your Shopify orders to see real sales.</p>
        <Link
          href="/import"
          className="inline-block px-5 py-2.5 bg-ink text-bone text-[12px] uppercase tracking-wide font-mono rounded-sm hover:bg-charcoal"
        >
          Go to Import
        </Link>
      </div>
    );
  }

  const { salesSummary, monthlySalesTrend, salesByChannel, topProducts, totals, thisMonthLabel } =
    stats;

  return (
    <div className="space-y-10">
      <section>
        <SectionLabel tag="01.1" title={`Sales Overview — ${thisMonthLabel}`} />
        <div className="grid grid-cols-4 gap-4">
          <StatCard
            tag="TOTAL SALES"
            label="This Month"
            value={`$${salesSummary.totalSalesThisMonth.toLocaleString()}`}
            sub={
              salesSummary.monthOverMonthChange >= 0
                ? `+${salesSummary.monthOverMonthChange}% MoM`
                : `${salesSummary.monthOverMonthChange}% MoM`
            }
            accent
          />
          <StatCard
            tag="ONLINE"
            label="Online Sales"
            value={`$${salesSummary.onlineSales.toLocaleString()}`}
          />
          <StatCard
            tag="KIOSK"
            label="Other Channels"
            value={`$${salesSummary.kioskSales.toLocaleString()}`}
          />
          <StatCard tag="ORDERS" label="Total Orders" value={salesSummary.orders} />
        </div>
      </section>

      <section className="grid grid-cols-2 gap-4">
        <StatCard
          tag="AOV"
          label="Average Order Value"
          value={`$${salesSummary.avgOrderValue}`}
        />
        <StatCard
          tag="BEST SELLER"
          label="Top Product This Month"
          value={salesSummary.bestSellingProduct}
        />
      </section>

      {/* All-time summary */}
      <section className="card p-6 shadow-card">
        <SectionLabel tag="01.5" title="All-Time Totals" />
        <div className="grid grid-cols-4 gap-4 text-[13px]">
          <Stat label="Orders (all time)" value={totals.orderCount.toLocaleString()} />
          <Stat label="Paid orders" value={totals.paidCount.toLocaleString()} />
          <Stat label="Refunded" value={totals.refundedCount.toLocaleString()} />
          <Stat
            label="Net revenue"
            value={`$${totals.netRevenue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`}
          />
        </div>
      </section>

      <section className="grid grid-cols-3 gap-5">
        <div className="card p-6 col-span-2 shadow-card">
          <SectionLabel tag="01.2" title="Sales Trend — 6 Months" />
          <SalesTrendChart data={monthlySalesTrend} />
        </div>
        <div className="card p-6 shadow-card">
          <SectionLabel tag="01.3" title="Channel Split" />
          <ChannelDonut data={salesByChannel} />
        </div>
      </section>

      <section className="card p-6 shadow-card">
        <SectionLabel tag="01.4" title="Top Products" />
        {topProducts.length === 0 ? (
          <p className="text-[13px] text-ash">No products sold this month.</p>
        ) : (
          <table className="w-full text-[13px]">
            <thead>
              <tr className="text-left text-[11px] font-mono uppercase text-fog hairline pb-2">
                <th className="py-3 font-medium">Product</th>
                <th className="py-3 font-medium">Units Sold</th>
                <th className="py-3 font-medium">Revenue</th>
              </tr>
            </thead>
            <tbody>
              {topProducts.map((p) => (
                <tr key={p.name} className="hairline">
                  <td className="py-3 font-medium">{p.name}</td>
                  <td className="py-3 font-mono text-ash">{p.units}</td>
                  <td className="py-3 font-mono">
                    ${p.revenue.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <div className="text-[10px] font-mono text-fog uppercase tracking-widest2">{label}</div>
      <div className="font-display text-2xl mt-1">{value}</div>
    </div>
  );
}
