"use client";

import { useState, useRef } from "react";
import { Upload, FileCheck, AlertCircle, Loader2 } from "lucide-react";
import { parseShopifyCsv, summarizeParsed } from "@/lib/shopifyParser";
import SectionLabel from "@/components/SectionLabel";

export default function ImportPage() {
  const [dragging, setDragging] = useState(false);
  const [parsed, setParsed] = useState(null);
  const [filename, setFilename] = useState("");
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);

  async function handleFile(file) {
    setError(null);
    setResult(null);
    setParsed(null);
    setFilename(file.name);
    try {
      const text = await file.text();
      const parsedData = parseShopifyCsv(text);
      if (parsedData.orders.length === 0) {
        setError("No orders found in this file. Is it really a Shopify orders export?");
        return;
      }
      setParsed(parsedData);
    } catch (err) {
      setError("Couldn't read the file: " + (err.message || "unknown error"));
    }
  }

  function onDrop(e) {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  }

  function onPick(e) {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }

  async function confirmImport() {
    if (!parsed) return;
    setImporting(true);
    setError(null);
    try {
      const res = await fetch("/api/orders/import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(parsed),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Import failed");
      setResult(data);
      setParsed(null);
      setFilename("");
    } catch (err) {
      setError(err.message);
    } finally {
      setImporting(false);
    }
  }

  const summary = parsed ? summarizeParsed(parsed) : null;

  return (
    <div className="space-y-6 max-w-3xl">
      <SectionLabel tag="07.1" title="Import Shopify Orders" />

      <p className="text-[13px] text-ash leading-relaxed">
        Export your Shopify orders as a Plain CSV file, then drop it below. Duplicate orders are
        automatically skipped — safe to re-upload the same file or overlapping date ranges.
      </p>

      {/* Drop zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`card p-12 text-center cursor-pointer transition-colors shadow-card ${
          dragging ? "bg-charcoal/5 border-ink" : ""
        }`}
      >
        <Upload size={32} strokeWidth={1.5} className="mx-auto mb-3 text-ash" />
        <div className="font-display text-base uppercase tracking-wide mb-1">
          {filename || "Drop CSV here"}
        </div>
        <div className="text-[11px] font-mono text-fog">or click to browse</div>
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,text/csv"
          onChange={onPick}
          className="hidden"
        />
      </div>

      {error && (
        <div className="card p-4 border-tag border-l-2 flex items-start gap-3 shadow-card">
          <AlertCircle size={18} className="text-tag mt-0.5 shrink-0" />
          <div className="text-[13px]">{error}</div>
        </div>
      )}

      {summary && (
        <div className="card p-6 shadow-card space-y-4">
          <div className="flex items-center gap-2">
            <FileCheck size={18} className="text-ink" />
            <div className="font-display text-base uppercase tracking-wide">Preview</div>
          </div>
          <div className="grid grid-cols-2 gap-3 text-[13px]">
            <Row label="File" value={filename} />
            <Row label="Orders found" value={summary.orderCount.toLocaleString()} />
            <Row label="Paid" value={summary.paidCount.toLocaleString()} />
            <Row label="Refunded" value={summary.refundedCount.toLocaleString()} />
            <Row label="Line items" value={summary.lineItemCount.toLocaleString()} />
            <Row label="Gross revenue" value={`$${summary.grossRevenue.toFixed(2)}`} />
            <Row label="Net revenue" value={`$${summary.netRevenue.toFixed(2)}`} />
            <Row
              label="Date range"
              value={
                summary.dateRange
                  ? `${summary.dateRange.start} → ${summary.dateRange.end}`
                  : "—"
              }
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              onClick={confirmImport}
              disabled={importing}
              className="focus-ring px-5 py-2.5 bg-ink text-bone text-[12px] uppercase tracking-wide font-mono rounded-sm hover:bg-charcoal disabled:opacity-50 flex items-center gap-2"
            >
              {importing && <Loader2 size={14} className="animate-spin" />}
              {importing ? "Importing..." : "Confirm Import"}
            </button>
            <button
              onClick={() => {
                setParsed(null);
                setFilename("");
              }}
              disabled={importing}
              className="focus-ring px-5 py-2.5 border border-mist text-ash text-[12px] uppercase tracking-wide font-mono rounded-sm hover:bg-charcoal/5"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {result && (
        <div className="card p-6 border-l-2 border-ink shadow-card">
          <div className="font-display text-base uppercase tracking-wide mb-3">
            Import complete
          </div>
          <div className="space-y-1.5 text-[13px]">
            <Row label="New orders added" value={result.inserted} />
            <Row label="Duplicates skipped" value={result.skipped} />
            <Row label="Total processed" value={result.total} />
          </div>
          <p className="text-[11px] text-fog font-mono mt-4">
            Your dashboard now reflects the latest data. Visit Sales or the home page to see it.
          </p>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex justify-between border-b border-ink/5 py-1.5">
      <span className="text-ash">{label}</span>
      <span className="font-mono">{value}</span>
    </div>
  );
}
