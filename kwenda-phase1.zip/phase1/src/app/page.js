import Link from "next/link";
import StatCard from "@/components/StatCard";
import SectionLabel from "@/components/SectionLabel";
import { StatusBadge, PriorityBadge } from "@/components/Badge";
import SalesTrendChart from "@/components/charts/SalesTrendChart";
import GrowthChart from "@/components/charts/GrowthChart";
import { getDashboardStats } from "@/lib/computeStats";
import {
  socialSummary,
  actionPlans,
  futureDrops,
  calendarEvents,
  eventTypeStyles,
  statusStyles,
  priorityStyles,
} from "@/data/sampleData";
import { Upload } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const stats = await getDashboardStats();

  // Empty state — no orders imported yet
  if (!stats.hasData) {
    return (
      <div className="space-y-6">
        <SectionLabel tag="00.0" title="Welcome to KWENDA" />
        <div className="card p-10 text-center shadow-card">
          <Upload size={32} strokeWidth={1.5} className="mx-auto mb-4 text-ash" />
          <div className="font-display text-xl uppercase tracking-wide mb-2">
            No sales data yet
          </div>
          <p className="text-[13px] text-ash mb-6 max-w-md mx-auto">
            Import your Shopify orders to see real numbers, trends, and best sellers across your
            whole dashboard.
          </p>
          <Link
            href="/import"
            className="inline-block px-5 py-2.5 bg-ink text-bone text-[12px] uppercase tracking-wide font-mono rounded-sm hover:bg-charcoal"
          >
            Go to Import
          </Link>
        </div>
      </div>
    );
  }

  const { salesSummary, monthlySalesTrend, thisMonthLabel } = stats;
  const upcoming = actionPlans.filter((p) => p.status !== "Done").slice(0, 4);
  const nextEvents = calendarEvents.slice(0, 4);
  const nextDrop = futureDrops[0];

  return (
    <div className="space-y-10">
      <section>
        <SectionLabel
          tag="00.1"
          title={`At a Glance — ${thisMonthLabel}`}
          action={
            <Link
              href="/import"
              className="text-[11px] font-mono text-fog hover:text-ink uppercase"
            >
              + Import More
            </Link>
          }
        />
        <div className="grid grid-cols-4 gap-4">
          <StatCard
            tag="TOTAL SALES"
            label="This Month"
            value={`$${salesSummary.totalSalesThisMonth.toLocaleString()}`}
            sub={
              salesSummary.monthOverMonthChange >= 0
                ? `+${salesSummary.monthOverMonthChange}% vs last month`
                : `${salesSummary.monthOverMonthChange}% vs last month`
            }
            accent
          />
          <StatCard
            tag="ORDERS"
            label="Total Orders"
            value={salesSummary.orders}
            sub={`AOV $${salesSummary.avgOrderValue}`}
          />
          <StatCard
            tag="BEST SELLER"
            label="Top Product"
            value={salesSummary.bestSellingProduct}
          />
          <StatCard
            tag="IG FOLLOWERS"
            label="Instagram"
            value={socialSummary.instagramFollowers.toLocaleString()}
            sub={`+${socialSummary.followerGrowthThisWeek}% this week`}
          />
        </div>
      </section>

      <section className="grid grid-cols-3 gap-5">
        <div className="card p-6 col-span-2 shadow-card">
          <SectionLabel tag="01" title="Sales Trend — 6 Months" />
          <SalesTrendChart data={monthlySalesTrend} />
        </div>
        <div className="card p-6 shadow-card">
          <SectionLabel tag="05" title="Next Drop" />
          <div className="space-y-3">
            <div className="font-display text-xl">{nextDrop.name}</div>
            <div className="text-xs text-ash font-mono">{nextDrop.productType}</div>
            <div className="hairline pt-3 space-y-2 text-[13px]">
              <div className="flex justify-between">
                <span className="text-ash">Launch date</span>
                <span className="font-mono">{nextDrop.plannedDate}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-ash">Inventory</span>
                <StatusBadge status={nextDrop.inventoryStatus} styles={statusStyles} />
              </div>
              <div className="flex justify-between items-center">
                <span className="text-ash">Marketing</span>
                <StatusBadge status={nextDrop.marketingStatus} styles={statusStyles} />
              </div>
              <div className="flex justify-between items-center">
                <span className="text-ash">Launch</span>
                <StatusBadge status={nextDrop.launchStatus} styles={statusStyles} />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-3 gap-5">
        <div className="card p-6 col-span-2 shadow-card">
          <SectionLabel tag="02" title="Weekly Growth — IG / TikTok / Visits" />
          <GrowthChart />
        </div>
        <div className="card p-6 shadow-card">
          <SectionLabel tag="03" title="Upcoming on Calendar" />
          <ul className="space-y-3">
            {nextEvents.map((e) => (
              <li key={e.id} className="flex items-start gap-3">
                <span className={`mt-1.5 w-1.5 h-1.5 rounded-full ${eventTypeStyles[e.type].dot}`} />
                <div>
                  <div className="text-[13px] font-medium leading-tight">{e.title}</div>
                  <div className="text-[11px] font-mono text-fog">{e.date}</div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="card p-6 shadow-card">
        <SectionLabel tag="04" title="Action Plans — Needs Attention" />
        <div className="grid grid-cols-2 gap-3">
          {upcoming.map((p) => (
            <div key={p.id} className="hairline pt-3 flex items-center justify-between">
              <div>
                <div className="text-[11px] font-mono text-fog uppercase">{p.category}</div>
                <div className="text-[14px] font-medium">{p.title}</div>
                <div className="text-[11px] text-ash mt-0.5">
                  {p.owner} · due {p.dueDate}
                </div>
              </div>
              <div className="flex flex-col items-end gap-1.5">
                <StatusBadge status={p.status} styles={statusStyles} />
                <PriorityBadge priority={p.priority} styles={priorityStyles} />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
