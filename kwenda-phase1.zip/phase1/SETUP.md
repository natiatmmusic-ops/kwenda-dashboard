# KWENDA Dashboard — Phase 1 Setup Guide

Phase 1 adds Shopify CSV import + a real database so your data persists forever.

---

## What's in this zip

8 files. Each one replaces or adds to a file in your existing project.

| File in this zip | Where it goes on GitHub |
|---|---|
| `package.json` | replaces `package.json` (root) |
| `src/lib/db.js` | **NEW** — create `src/lib/` folder if missing |
| `src/lib/shopifyParser.js` | **NEW** |
| `src/lib/computeStats.js` | **NEW** |
| `src/app/api/orders/import/route.js` | **NEW** — create `src/app/api/orders/import/` folders |
| `src/app/import/page.js` | **NEW** — create `src/app/import/` folder |
| `src/app/page.js` | replaces existing `src/app/page.js` |
| `src/app/sales/page.js` | replaces existing `src/app/sales/page.js` |
| `src/components/Sidebar.jsx` | replaces existing |
| `src/components/Topbar.jsx` | replaces existing |
| `src/components/charts/SalesTrendChart.jsx` | replaces existing |
| `src/components/charts/ChannelDonut.jsx` | replaces existing |

---

## Setup — three big steps

### STEP 1: Add a Vercel Postgres database (5 min)

1. Go to **vercel.com** → log in
2. Open your **kwenda-dashboard** project
3. Click the **Storage** tab at the top
4. Click **Create Database** → choose **Postgres**
5. Name: `kwenda-db` → region: closest to you → click **Create**
6. Vercel automatically connects it to your project — you don't need to do anything else here

That's it. The database is live and your project knows how to talk to it.

### STEP 2: Upload these new files to GitHub (10 min)

For each file in the table above:

- If it says **NEW**: Create the folders, then upload the file
- If it says **replaces**: Navigate to that file on GitHub, click pencil ✏️, delete everything, paste the new contents

**Tip:** the easiest way to do many files at once is to delete the whole `src/` folder on GitHub and re-upload it from your computer. But if you've made any edits, do it file by file.

### STEP 3: Wait for Vercel to redeploy (2 min)

After you commit the changes, Vercel auto-detects them and redeploys. Watch the deploy logs — if anything errors, screenshot it and I'll fix.

---

## How to use it

1. Once deployed, visit your live site
2. Click **Import Data** in the sidebar (item 07)
3. Drag your Shopify CSV onto the drop zone
4. Review the preview (number of orders, revenue, date range)
5. Click **Confirm Import**
6. Go back to Dashboard or Sales — your real numbers are now live

**You can re-upload the same file safely.** Duplicate orders (same Shopify Order ID) are auto-skipped.

---

## Importing your full 2-year history

1. In Shopify Admin → Orders → Export → choose **All orders** → Plain CSV
2. Wait for Shopify to email you the file (large exports get emailed, not downloaded)
3. Save the file
4. Drag it onto the Import page → Confirm

All 2 years populate at once.

---

## What still uses sample data (Phase 2 will fix)

- Social Media page (still shows fake follower counts)
- Calendar (still shows fake events)
- Action Plans (still shows fake plans)
- Future Drops (still shows fake drops)

The home Dashboard and Sales page now pull real numbers from your Shopify imports.

Phase 2 will: add year-over-year analysis, refund toggle, product drill-down with sizes, and let you save real action plans and drops to the database too.
